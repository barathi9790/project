document.getElementById('event-form').addEventListener('submit', function(e) {
  e.preventDefault();

  const title = document.getElementById('title').value;
  const date = document.getElementById('date').value;
  const location = document.getElementById('location').value;
  const description = document.getElementById('description').value;

  const eventList = document.getElementById('event-list');

  const eventCard = document.createElement('div');
  eventCard.innerHTML = `
    <h3>${title}</h3>
    <p><strong>Date:</strong> ${date}</p>
    <p><strong>Location:</strong> ${location}</p>
    <p>${description}</p>
    <hr/>
  `;

  eventList.appendChild(eventCard);

  this.reset();
});
